package in.Cdac.DiscountCalculationforRetailSales;

import java.util.Scanner;

class Discount_Calculation{
	private double originalPrice;
    private double discountRate;
    public void acceptRecord() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the original price of the item (in Rs.): ");
        originalPrice = sc.nextDouble();
        System.out.print("Enter the discount percentage: ");
        discountRate = sc.nextDouble();
    }
    public double calculateDiscount() {
        return originalPrice * (discountRate / 100);
    }
    public void printRecord() {
        double discountAmount = calculateDiscount();
        double finalPrice = originalPrice - discountAmount;
        System.out.printf("Discount Amount:  %.2f\n", discountAmount);
        System.out.printf("Final Price after discount:  %.2f\n", finalPrice);
    }
}
public class Discount_Calculation_for_Retail_Sale {
	 public static void main(String[] args) {
	        Discount_Calculation cal = new Discount_Calculation();
	        cal.acceptRecord();
	        cal.printRecord();
	    }
}
