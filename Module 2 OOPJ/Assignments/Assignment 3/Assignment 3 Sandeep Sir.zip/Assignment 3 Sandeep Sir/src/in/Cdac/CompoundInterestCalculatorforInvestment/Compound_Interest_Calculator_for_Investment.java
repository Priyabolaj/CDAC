package in.Cdac.CompoundInterestCalculatorforInvestment;

import java.util.Scanner;

class Compound_Interest_Calculator {
	private double principal;
	private double annualInterestRate;
	private int numberOfCompounds;
	private int investmentDuration;


	public void acceptRecord() {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the initial investment amount (Principal):  ");
		principal = sc.nextDouble();
		System.out.print("Enter the annual interest rate (in %): ");
		annualInterestRate = sc.nextDouble();
		System.out.print("Enter the number of times the interest is compounded per year: ");
		numberOfCompounds = sc.nextInt();
		System.out.print("Enter the investment duration (in years): ");
		investmentDuration = sc.nextInt();
	}


	public double calculateFutureValue() {
		double rate = annualInterestRate / 100;

		double futureValue = principal * Math.pow(1 + rate / numberOfCompounds, numberOfCompounds * investmentDuration);

		return futureValue;
	}
	public void printRecord() {
		double futureValue = calculateFutureValue();
		double totalInterest = futureValue - principal;
		System.out.printf("Future Value of Investment:  %.2f\n", futureValue);
		System.out.printf("Total Interest Earned:  %.2f\n", totalInterest);
	}
}

public class Compound_Interest_Calculator_for_Investment {
	public static void main(String[] args) {
        Compound_Interest_Calculator cal = new Compound_Interest_Calculator();
        cal.acceptRecord();
        cal.printRecord();
    }
}
