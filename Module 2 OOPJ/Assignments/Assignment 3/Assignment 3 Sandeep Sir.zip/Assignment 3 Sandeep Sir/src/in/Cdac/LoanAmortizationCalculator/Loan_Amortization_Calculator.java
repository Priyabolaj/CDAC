package in.Cdac.LoanAmortizationCalculator;

import java.util.Scanner;

class Loan_Calculator {
	private double principal;
	private double annualInterestRate;
	private int loanTerm;

	public void acceptRecord() {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the loan amount (Principal):  ");
		principal = sc.nextDouble();
		System.out.print("Enter the annual interest rate (in %): ");
		annualInterestRate = sc.nextDouble();
		System.out.print("Enter the loan term (in years): ");
		loanTerm = sc.nextInt();
	}

	public double calculateMonthlyPayment() {

		double monthlyInterestRate = (annualInterestRate / 12) / 100;

		int numberOfMonths = loanTerm * 12;

		double monthlyPayment = principal * (monthlyInterestRate * Math.pow(1 + monthlyInterestRate, numberOfMonths))
				/ (Math.pow(1 + monthlyInterestRate, numberOfMonths) - 1);

		return monthlyPayment;
	}

	public void printRecord() {
		double monthlyPayment = calculateMonthlyPayment();
		double totalPayment = monthlyPayment * loanTerm * 12;
		System.out.printf("Monthly Payment:  %.2f\n", monthlyPayment);
		System.out.printf("Total Amount Paid over the life of the loan:  %.2f\n", totalPayment);
	}
}

public class Loan_Amortization_Calculator {
	public static void main(String[] args) {
		Loan_Calculator cal = new Loan_Calculator();
		cal.acceptRecord();
		cal.printRecord();
	}
}
