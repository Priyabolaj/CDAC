package in.Cdac.TollBoothRevenueManagement;

import java.util.Scanner;

class Toll_Booth_Revenue{
	private double carRate;
    private double truckRate;
    private double motorcycleRate;
    private int numberOfCars;
    private int numberOfTrucks;
    private int numberOfMotorcycles;
    public void acceptRecord() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the number of cars: ");
        numberOfCars = sc.nextInt();
        System.out.print("Enter the number of trucks: ");
        numberOfTrucks = sc.nextInt();
        System.out.print("Enter the number of motorcycles: ");
        numberOfMotorcycles = sc.nextInt();
    }
    public void setTollRates() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Set the toll rate for a car (in Rs.): ");
        carRate = sc.nextDouble();
        System.out.print("Set the toll rate for a truck (in Rs.): ");
        truckRate = sc.nextDouble();
        System.out.print("Set the toll rate for a motorcycle (in Rs.): ");
        motorcycleRate = sc.nextDouble();
    }
    public double calculateRevenue() {
        double totalRevenue = (numberOfCars * carRate) + (numberOfTrucks * truckRate) + (numberOfMotorcycles * motorcycleRate);
        return totalRevenue;
    }
    public void printRecord() {
        int totalVehicles = numberOfCars + numberOfTrucks + numberOfMotorcycles;
        double totalRevenue = calculateRevenue();
        System.out.println("Total number of vehicles: " + totalVehicles);
        System.out.printf("Total revenue collected: Rs. %.2f\n", totalRevenue);
    }
}
public class Toll_Booth_Revenue_Management {
	public static void main(String[] args) {
        Toll_Booth_Revenue r1 = new Toll_Booth_Revenue();
        r1.setTollRates();
        r1.acceptRecord();
        r1.printRecord();
    }
}
