package in.Cdac.Employee;

import java.util.Scanner;

class Employee {
	private static int totalEmployees = 0;
	private static double totalSalaryExpense = 0.0;
	private int id;
	private String name;
	private double salary;
	
	static {
		System.out.println("Employee system initialized.");
	}
	
	{
		totalEmployees++;
		System.out.println("New employee added.");
	}

	public Employee(int id, String name, double salary) {
		this.id = id;
		this.name = name;
		this.salary = salary;
		totalSalaryExpense += salary;
	}

	public static int getTotalEmployees() {
		return totalEmployees;
	}

	public void applyRaise(double percentage) {
		double raiseAmount = (salary * percentage) / 100;
		totalSalaryExpense -= salary;
		salary += raiseAmount;
		totalSalaryExpense += salary;
	}

	public static double calculateTotalSalaryExpense() {
		return totalSalaryExpense;
	}

	public void updateSalary(double newSalary) {
		totalSalaryExpense -= salary;
		salary = newSalary;
		totalSalaryExpense += salary;
	}

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public double getSalary() {
		return salary;
	}

	public String toString() {
		return "Employee [\nid=" + id + "\nname=" + name + "\nsalary=" + salary + "\n]";
	}
}

class EmployeeUtil {
	private static Scanner sc = new Scanner(System.in);

	public void displayTotalEmployees() {
		System.out.println("Total Employees: " + Employee.getTotalEmployees());
	}

	public void displayTotalSalaryExpense() {
		System.out.println("Total Salary Expense: $" + Employee.calculateTotalSalaryExpense());
	}

	public void applyRaiseToEmployee(Employee emp1, Employee emp2) {
		System.out.print("Enter Employee ID to apply raise (101 or 102): ");
		int empId = sc.nextInt();
		System.out.print("Enter raise percentage: ");
		double raise = sc.nextDouble();
		if (empId == emp1.getId()) {
			emp1.applyRaise(raise);
		} else if (empId == emp2.getId()) {
			emp2.applyRaise(raise);
		} else {
			System.out.println("Employee not found.");
		}
	}

	public void updateSalaryOfEmployee(Employee emp1, Employee emp2) {
		System.out.print("Enter Employee ID to update salary (101 or 102): ");
		int empId = sc.nextInt();
		System.out.print("Enter new salary: ");
		double newSalary = sc.nextDouble();
		if (empId == emp1.getId()) {
			emp1.updateSalary(newSalary);
		} else if (empId == emp2.getId()) {
			emp2.updateSalary(newSalary);
		} else {
			System.out.println("Employee not found.");
		}
	}

	public void displayEmployeeDetails(Employee emp1, Employee emp2) {
		System.out.print("Enter Employee ID to view details (101 or 102): ");
		int empId = sc.nextInt();
		if (empId == emp1.getId()) {
			System.out.println(emp1);
		} else if (empId == emp2.getId()) {
			System.out.println(emp2);
		} else {
			System.out.println("Employee not found.");
		}
	}

	public static int menuList() {
		System.out.println("\nMenu:");
		System.out.println("1. Display Total Employees");
		System.out.println("2. Display Total Salary Expense");
		System.out.println("3. Apply Raise to an Employee");
		System.out.println("4. Update Salary of an Employee");
		System.out.println("5. Display Employee Details");
		System.out.println("0. Exit");
		System.out.print("Enter your choice: ");
		return sc.nextInt();
	}
}

public class Program {
	public static void main(String[] args) {
		int choice;
		Employee emp1 = new Employee(101, "John Doe", 50000);
		Employee emp2 = new Employee(102, "Jane Smith", 60000);
		EmployeeUtil util = new EmployeeUtil();

		while ((choice = EmployeeUtil.menuList()) != 0) {
			switch (choice) {
				case 1:
					util.displayTotalEmployees();
					break;
				case 2:
					util.displayTotalSalaryExpense();
					break;
				case 3:
					util.applyRaiseToEmployee(emp1, emp2);
					break;
				case 4:
					util.updateSalaryOfEmployee(emp1, emp2);
					break;
				case 5:
					util.displayEmployeeDetails(emp1, emp2);
					break;
				default:
					System.out.println("Invalid choice, please try again.");
			}
		}

	}
}
