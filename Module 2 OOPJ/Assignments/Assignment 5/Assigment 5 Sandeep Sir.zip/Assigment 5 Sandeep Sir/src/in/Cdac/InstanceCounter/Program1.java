package in.Cdac.InstanceCounter;

class InstanceCounter {
	private static int instanceCount = 0;
    public InstanceCounter() {
        instanceCount++;
    }
    public static int getInstanceCount() {
        return instanceCount;
    }
}
public class Program1{
	public static void main(String[] args) {
		InstanceCounter i1 =new InstanceCounter();
		InstanceCounter i2 =new InstanceCounter();
		InstanceCounter i3 =new InstanceCounter();

        System.out.println("Number of instances created: " + InstanceCounter.getInstanceCount());
    }
}