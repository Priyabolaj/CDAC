package in.Cdac.Float;

public class Q6_K {
	public static void main(String[] args) {
		float a= -25.0f;
		System.out.println(Math.sqrt(a));
	}
}
