package in.Cdac.Byte;

public class Q2_E {
	public static void main(String[] args) {
		String strNumber = "5";
		byte b = Byte.parseByte(strNumber);
		System.out.println(b);
	}
}
