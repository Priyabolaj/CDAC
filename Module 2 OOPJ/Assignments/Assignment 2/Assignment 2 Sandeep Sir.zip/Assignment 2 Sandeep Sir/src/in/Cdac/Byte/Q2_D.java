package in.Cdac.Byte;

public class Q2_D {
	public static void byte1() {
		byte num = 45;
		String str = Byte.toString(num);
		System.out.println(str);
	}
	public static void main(String[] args) {
		byte b = Byte.BYTES;
		System.out.println(Byte.MIN_VALUE);
		System.out.println(Byte.MAX_VALUE);
		byte1();
	} 
}
