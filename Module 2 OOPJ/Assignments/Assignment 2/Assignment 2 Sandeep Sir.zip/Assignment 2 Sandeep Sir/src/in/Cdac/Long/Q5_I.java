package in.Cdac.Long;

public class Q5_I {
	public static void main(String[] args) {
		long a = 1123;
		long b = 9845;
		System.out.println(Long.sum(a, b));
	}
}
