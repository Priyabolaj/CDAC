package in.Cdac.Long;

public class Q5_B {
	public static void main(String[] args) {
		long b = Long.BYTES;
		System.out.println(b);
	}
}
