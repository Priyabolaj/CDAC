package in.Cdac.Double;

public class Q7_H {
	public static void main(String[] args) {
		String strNumber = "12.45";
		double b = Double.valueOf(strNumber);
		System.out.println(b);
	}
}
