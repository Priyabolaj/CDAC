package in.Cdac.Double;

public class Q7_L {
	public static void main(String[] args) {
		double a = 0.0;
		double b =0.0;
		System.out.println(a/b);
	}
}
