package in.Cdac.Short;

public class Q3_E {
	public static void main(String[] args) {
		String strNumber = "4586";
		short sh = Short.parseShort(strNumber);
		System.out.println(sh);
	}
}
