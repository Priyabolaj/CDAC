package in.Cdac.Boolean;

public class Q1_D {
	public static void main(String[] args) {
		String strStatus =" 0 ";
		boolean bool = Boolean.parseBoolean(strStatus);
		System.out.println(bool);
	}
}
