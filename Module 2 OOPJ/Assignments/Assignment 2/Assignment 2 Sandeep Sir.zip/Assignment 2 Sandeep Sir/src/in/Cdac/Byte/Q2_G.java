package in.Cdac.Byte;

public class Q2_G {
	public static void main(String[] args) {
		byte b1 = 5;
		byte b = Byte.valueOf(b1);
		System.out.println(b);
	}
}
