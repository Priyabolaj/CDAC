package in.Cdac.Long;

public class Q5_H {
	public static void main(String[] args) {
		String strNumber = "1245";
		long b = Long.valueOf(strNumber);
		System.out.println(b);
	}
}
