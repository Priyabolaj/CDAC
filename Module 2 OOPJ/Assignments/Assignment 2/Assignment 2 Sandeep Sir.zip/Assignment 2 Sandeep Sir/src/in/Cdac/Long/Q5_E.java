package in.Cdac.Long;

public class Q5_E {
	public static void main(String[] args) {
		String strNumber = "23532";
		long b = Long.parseLong(strNumber);
		System.out.println(b);
	}
}
