package in.Cdac.Short;

public class Q3_H {
	public static void short1() {
		String strNumber = "4242";
		short sh = Short.valueOf(strNumber);
		System.out.println(sh);
	}
	public static void main(String[] args) {
		short1();
	}
}
