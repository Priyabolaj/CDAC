package in.Cdac.Integer;

public class Q4_I {
	public static void main(String[] args) {
		int a=10;
		int b=20;
		System.out.println(Integer.sum(a,b));
	}
}