package in.Cdac.Short;

public class Q3_D {
	public static void main(String[] args) {
		short num = 3352;
		String n1 = Short.toString(num);
		System.out.println(n1);
	}
}
