package in.Cdac.Float;

public class Q6_I {
	public static void main(String[] args) {
		float a = 112.3f;
		float b = 984.5f;
		System.out.println(Float.sum(a, b));
	}
}
