package in.Cdac.Float;

public class Q6_F {
	public static void main(String[] args) {
		String strNumber = "Ab12Cd3";
		float b = Float.parseFloat(strNumber);
		System.out.println(b);
	}
}
