package in.Cdac.Byte;

public class Q2_F {
	public static void main(String[] args) {
		String strNumber = "Ab12Cd3";
		byte b = Byte.parseByte(strNumber);
		System.out.println(b);
	}
}
