package in.Cdac.Float;

public class Q6_E {
	public static void main(String[] args) {
		String strNumber = "23532";
		float b = Float.parseFloat(strNumber);
		System.out.println(b);
	}
}
