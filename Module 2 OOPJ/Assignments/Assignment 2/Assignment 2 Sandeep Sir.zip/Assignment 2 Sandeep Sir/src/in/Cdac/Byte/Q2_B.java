package in.Cdac.Byte;

public class Q2_B {
	public static void main(String[] args)
	{
		byte b = Byte.BYTES;
		System.out.println(b);
	}
}
