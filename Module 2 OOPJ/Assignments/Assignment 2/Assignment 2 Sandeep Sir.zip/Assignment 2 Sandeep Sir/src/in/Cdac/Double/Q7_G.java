package in.Cdac.Double;

public class Q7_G {
	public static void main(String[] args) {
		double b = 558.2;
		double by = Double.valueOf(b);
		System.out.println(by);
	}
}
