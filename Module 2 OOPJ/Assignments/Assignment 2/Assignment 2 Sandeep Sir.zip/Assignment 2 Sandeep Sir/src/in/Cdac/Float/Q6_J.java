package in.Cdac.Float;

public class Q6_J {
	public static void main(String[] args) {
		float a=112.2f;
		float b=556.6f;
		System.out.println(Float.min(a,b));
		System.out.println(Float.max(a,b));
	}
}
