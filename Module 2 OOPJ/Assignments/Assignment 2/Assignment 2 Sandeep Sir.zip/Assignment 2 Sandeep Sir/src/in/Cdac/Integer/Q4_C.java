package in.Cdac.Integer;

public class Q4_C {
	public static void main(String[] args) {
		int b = Integer.BYTES;
		System.out.println(b);
		System.out.println(Integer.MIN_VALUE);
		System.out.println(Integer.MAX_VALUE);
	}
}
