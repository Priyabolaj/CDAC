package in.Cdac.Short;

public class Q3_G {
	public static void short1() {
		short number = 4242;
		short sh = Short.valueOf(number);
		System.out.println(sh);
	}
	public static void main(String[] args) {
		short1();
	}
}
