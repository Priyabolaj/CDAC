package in.Cdac.Double;

public class Q7_I {
	public static void main(String[] args) {
		double a = 112.3;
		double b = 984.5;
		System.out.println(Double.sum(a, b));
	}
}
