package in.Cdac.Long;
public class Q5_D {
	public static void main(String[] args) {
		long num = 12412;
		String str = Long.toString(num);
		System.out.println(str);
	}
}
