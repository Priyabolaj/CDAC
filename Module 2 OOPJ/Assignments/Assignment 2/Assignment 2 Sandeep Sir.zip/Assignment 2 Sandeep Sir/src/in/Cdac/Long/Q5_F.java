package in.Cdac.Long;

public class Q5_F {
	public static void main(String[] args) {
		String strNumber = "Ab12Cd3";
		long b = Long.parseLong(strNumber);
		System.out.println(b);
	}
}
