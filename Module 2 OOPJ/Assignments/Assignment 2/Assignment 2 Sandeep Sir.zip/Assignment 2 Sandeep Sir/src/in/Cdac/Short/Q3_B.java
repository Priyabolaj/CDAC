package in.Cdac.Short;

public class Q3_B {
	public static void main(String[] args)
	{
		System.out.println(Short.BYTES);
	}
}
