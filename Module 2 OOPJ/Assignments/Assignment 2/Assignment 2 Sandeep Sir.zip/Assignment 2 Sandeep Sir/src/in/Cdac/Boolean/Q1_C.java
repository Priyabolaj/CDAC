package in.Cdac.Boolean;

public class Q1_C {
	public static void main(String[] args) {
		String strStatus = "true";
		boolean bool = Boolean.parseBoolean(strStatus);
		System.out.println(bool);
	}
}
