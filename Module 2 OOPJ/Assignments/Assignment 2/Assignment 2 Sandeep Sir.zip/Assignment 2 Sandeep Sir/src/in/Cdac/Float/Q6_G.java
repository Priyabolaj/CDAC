package in.Cdac.Float;

public class Q6_G {
	public static void main(String[] args) {
		float b = 558.2f;
		float by = Float.valueOf(b);
		System.out.println(by);
	}
}
