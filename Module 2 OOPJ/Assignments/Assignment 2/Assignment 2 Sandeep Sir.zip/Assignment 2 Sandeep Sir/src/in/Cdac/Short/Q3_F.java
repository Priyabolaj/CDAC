package in.Cdac.Short;

public class Q3_F {
	public static void main(String[] args) {
		String strNumber = "Ab12Cd3";
		short sh = Short.parseShort(strNumber);
		System.out.println(sh);
	}
}
