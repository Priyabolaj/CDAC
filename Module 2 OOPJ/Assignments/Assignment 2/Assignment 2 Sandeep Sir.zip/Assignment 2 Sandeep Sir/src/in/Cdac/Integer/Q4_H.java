package in.Cdac.Integer;

public class Q4_H {
	public static void main(String[] args) {
		String strNumber = "25523523";
		int str = Integer.parseInt(strNumber);
		System.out.println(str);		
	}
}
