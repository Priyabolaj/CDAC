package in.Cdac.Double;
public class Q7_D {
	public static void main(String[] args) {
		double num = 124.12;
		String str = Double.toString(num);
		System.out.println(str);
	}
}
