package in.Cdac.Byte;

public class Q2_C {
	public static void main(String[] args)
	{
		byte b = Byte.BYTES;
		System.out.println(Byte.MIN_VALUE);
		System.out.println(Byte.MAX_VALUE);
	}
}
