package in.Cdac.Double;

public class Q7_F {
	public static void main(String[] args) {
		String strNumber = "Ab12Cd3";
		double b = Double.parseDouble(strNumber);
		System.out.println(b);
	}
}
