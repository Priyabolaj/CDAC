package in.Cdac.Integer;

public class Q4_F {
	public static void main(String[] args) {
		String num = "Ab12Cd3";
		int str = Integer.parseInt(num);
		System.out.println(str);		
	}
}
