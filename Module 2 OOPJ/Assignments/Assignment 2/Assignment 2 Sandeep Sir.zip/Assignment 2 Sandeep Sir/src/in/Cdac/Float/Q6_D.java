package in.Cdac.Float;
public class Q6_D {
	public static void main(String[] args) {
		float num = 12412;
		String str = Float.toString(num);
		System.out.println(str);
	}
}
