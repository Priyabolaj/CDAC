package in.Cdac.Long;

public class Q5_C {
	public static void main(String[] args) {
		System.out.println(Long.MIN_VALUE);
		System.out.println(Long.MIN_VALUE);
	}
}
