package in.Cdac.Double;

public class Q7_K {
	public static void main(String[] args) {
		double a= -25.0;
		System.out.println(Math.sqrt(a));
	}
}
