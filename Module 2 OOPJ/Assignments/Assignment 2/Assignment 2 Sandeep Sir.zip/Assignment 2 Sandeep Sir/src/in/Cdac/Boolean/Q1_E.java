package in.Cdac.Boolean;

public class Q1_E {
	public static void main(String[] args) {
		boolean status = true;
		boolean bool = Boolean.valueOf(status);
		System.out.println(bool);
	}
}
