package in.Cdac.Double;

public class Q7_J {
	public static void main(String[] args) {
		double a=112.2;
		double b=556.6;
		System.out.println(Double.min(a,b));
		System.out.println(Double.max(a,b));
	}
}
