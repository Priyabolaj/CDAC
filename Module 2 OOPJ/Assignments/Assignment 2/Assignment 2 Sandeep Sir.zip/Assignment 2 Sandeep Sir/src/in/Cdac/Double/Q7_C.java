package in.Cdac.Double;

public class Q7_C {
	public static void main(String[] args) {
		double b = Double.BYTES;
		System.out.println(Double.MIN_VALUE);
		System.out.println(Double.MAX_VALUE);
	}
}
