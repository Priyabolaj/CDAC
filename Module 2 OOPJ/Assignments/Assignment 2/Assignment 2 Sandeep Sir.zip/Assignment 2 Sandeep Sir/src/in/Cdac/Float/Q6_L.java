package in.Cdac.Float;

public class Q6_L {
	public static void main(String[] args) {
		float a = 0.0f;
		float b =0.0f;
		System.out.println(a/b);
	}
}
