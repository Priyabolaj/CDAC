package in.Cdac.Boolean;

public class Q1_F {
	public static void main(String[] args) {
		String strStatus ="true";
		boolean bool = Boolean.valueOf(strStatus);
		System.out.println(bool);
	}
}
