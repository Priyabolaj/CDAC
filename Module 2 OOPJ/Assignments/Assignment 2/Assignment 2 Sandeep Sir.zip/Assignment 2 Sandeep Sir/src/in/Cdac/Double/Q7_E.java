package in.Cdac.Double;

public class Q7_E {
	public static void main(String[] args) {
		String strNumber = "23.532";
		double b = Double.parseDouble(strNumber);
		System.out.println(b);
	}
}
