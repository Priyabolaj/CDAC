package in.Cdac.Long;

public class Q5_K {
	public static void main(String[] args) {
		long a=7;
		System.out.println(Long.toBinaryString(a));
		System.out.println(Long.toOctalString(a));
		System.out.println(Long.toHexString(a));
	}
}
