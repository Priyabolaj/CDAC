package in.Cdac.Long;

public class Q5_G {
	public static void main(String[] args) {
		long b = 558;
		long by = Long.valueOf(b);
		System.out.println(by);
	}
}
