package in.Cdac.Boolean;

public class Q1_B {
	public static void main(String[] args)
	{
		boolean status = true;
		String str = Boolean.toString(status);
		System.out.println(str);
	}
}
