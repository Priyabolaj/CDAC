package in.Cdac.Integer;

public class Q4_K {
	public static void main(String[] args) {
		int a=7;
		System.out.println(Integer.toBinaryString(a));
		System.out.println(Integer.toOctalString(a));
		System.out.println(Integer.toHexString(a));
	}
}
