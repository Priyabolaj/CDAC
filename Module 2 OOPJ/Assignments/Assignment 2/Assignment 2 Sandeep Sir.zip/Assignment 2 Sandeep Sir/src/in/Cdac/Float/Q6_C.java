package in.Cdac.Float;

public class Q6_C {
	public static void main(String[] args) {
		float b = Float.BYTES;
		System.out.println(b);
		System.out.println(Float.MIN_VALUE);
		System.out.println(Float.MAX_VALUE);
	}
}
