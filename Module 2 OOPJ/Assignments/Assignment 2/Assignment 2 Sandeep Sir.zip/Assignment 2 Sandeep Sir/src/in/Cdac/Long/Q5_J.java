package in.Cdac.Long;

public class Q5_J {
	public static void main(String[] args) {
		long a=1122;
		long b=5566;
		System.out.println(Long.max(a,b));
	}
}
