package in.Cdac.Integer;

public class Q4_B {
	public static void main(String[] args) {
		int b = Integer.BYTES;
		System.out.println(b);
	}
}
