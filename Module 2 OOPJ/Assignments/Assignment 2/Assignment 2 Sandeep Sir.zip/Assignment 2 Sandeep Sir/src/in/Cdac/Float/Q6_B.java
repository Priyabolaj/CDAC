package in.Cdac.Float;

public class Q6_B {
	public static void main(String[] args) {
		float b = Float.BYTES;
		System.out.println(b);
	}
}
