package in.Cdac.Integer;

public class Q4_G {
	public static void main(String[] args) {
		int num = 25523523;
		int b = Integer.valueOf(num);
		System.out.println(b);		
	}
}
