package in.Cdac.Double;

public class Q7_B {
	public static void main(String[] args) {
		double b = Double.BYTES;
		System.out.println(b);
	}
}
