package in.Cdac.Integer;

public class Q4_D {
	public static void main(String[] args) {
		int num = 25523523;
		String str = Integer.toString(num);
		System.out.println(str);		
	}
}
