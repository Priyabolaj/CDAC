package in.Cdac.Integer;

public class Q4_E {
	public static void main(String[] args) {
		String strNumber = "25523523";
		int b = Integer.parseInt(strNumber);
		System.out.println(b);		
	}
}
