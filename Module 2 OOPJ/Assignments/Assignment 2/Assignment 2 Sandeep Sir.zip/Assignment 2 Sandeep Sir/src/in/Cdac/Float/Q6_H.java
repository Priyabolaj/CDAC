package in.Cdac.Float;

public class Q6_H {
	public static void main(String[] args) {
		String strNumber = "1245";
		float b = Float.valueOf(strNumber);
		System.out.println(b);
	}
}
