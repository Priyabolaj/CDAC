//Q:- Create an employee class and call its methods from the reference

package org.Employee;

import java.util.Scanner;

class Info{
	private String name;
	private int empid;
	private float salary;
	private String position;
	private String location;
	public void acceptrecord() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Name: ");
		name=sc.nextLine();
		System.out.println("Enter EmpId: ");
		empid=sc.nextInt();
		System.out.println("Enter Salary: ");
		salary=sc.nextFloat();
		System.out.println("Enter Position: ");
		position=sc.next();
		System.out.println("Enter location: ");
		location=sc.next();
	}
	public void displayrecord() {
		System.out.println("Name: "+name+"\nEmpId: "+empid+"\nSalary: "+salary+"\nPosition: "+position+"\nlocation: "+location);
	}
}
public class Employee {
	public static void main(String[] args)
	{
		Info e1=new Info();
		Info e2=new Info();
		e1.acceptrecord();
		e1.displayrecord();
		e2.acceptrecord();
		e2.displayrecord();
	}

}
