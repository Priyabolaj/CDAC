package in.Cdac.CompoundInterestCalculatorforInvestment;

import java.util.Scanner;

class CompoundInterestCalculator {
	private double principal;
	private double annualInterestRate;
	private int numberOfCompounds;
	private int years;

	public CompoundInterestCalculator(double principal, double annualInterestRate, int numberOfCompounds, int years) {
		this.principal = principal;
		this.annualInterestRate = annualInterestRate;
		this.numberOfCompounds = numberOfCompounds;
		this.years = years;
	}
	public CompoundInterestCalculator() {
		// TODO Auto-generated constructor stub
	}
	public double getPrincipal() {
		return principal;
	}

	public void setPrincipal(double principal) {
		this.principal = principal;
	}

	public double getAnnualInterestRate() {
		return annualInterestRate;
	}

	public void setAnnualInterestRate(double annualInterestRate) {
		this.annualInterestRate = annualInterestRate;
	}

	public int getNumberOfCompounds() {
		return numberOfCompounds;
	}

	public void setNumberOfCompounds(int numberOfCompounds) {
		this.numberOfCompounds = numberOfCompounds;
	}

	public int getYears() {
		return years;
	}

	public void setYears(int years) {
		this.years = years;
	}

	
	public double calculateFutureValue() {
		return principal * Math.pow(1 + (annualInterestRate / 100) / numberOfCompounds, numberOfCompounds * years);
	}

	
	public double calculateTotalInterest() {
		return calculateFutureValue() - principal;
	}

	public String toString() {
		return "CompoundInterestCalculator [\nprincipal=" + principal + "\n annualInterestRate=" + annualInterestRate
				+ "\n numberOfCompounds=" + numberOfCompounds + "\n years=" + years + "\n getPrincipal()=" + getPrincipal()
				+ "\n getAnnualInterestRate()=" + getAnnualInterestRate() + "\n getNumberOfCompounds()="
				+ getNumberOfCompounds() + "\n getYears()=" + getYears() + "\n calculateFutureValue()="
				+ calculateFutureValue() + "\n calculateTotalInterest()=" + calculateTotalInterest() + "\n]";
	}

}

class CompoundInterestCalculatorUtil {
	private CompoundInterestCalculator investment;

	public CompoundInterestCalculatorUtil() {
		this.investment = new CompoundInterestCalculator();
	}

	private static Scanner sc = new Scanner(System.in);

	public void acceptRecord() {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter Initial Investment Amount (Rs.): ");
		double principal = scanner.nextDouble();
		System.out.print("Enter Annual Interest Rate (%): ");
		double annualInterestRate = scanner.nextDouble();
		System.out.print("Enter Number of Compounds Per Year: ");
		int numberOfCompounds = scanner.nextInt();
		System.out.print("Enter Investment Duration (years): ");
		int years = scanner.nextInt();
		investment = new CompoundInterestCalculator(principal, annualInterestRate, numberOfCompounds, years);
	}

	public void printRecord() {
		System.out.println(investment.toString());
	}

	public static int menuList() {
		System.out.println("0.Exit");
		System.out.println("1.Accept Record");
		System.out.println("2.Print Record");
		System.out.print("Enter choice	:	");
		return sc.nextInt();
	}

	public static void releaseResource() {
		sc.close();
	}
}

public class Program {
	public static void main(String[] args) {
		int choice;
		CompoundInterestCalculatorUtil util = new CompoundInterestCalculatorUtil();
		while ((choice = CompoundInterestCalculatorUtil.menuList()) != 0) {
			switch (choice) {
			case 1:
				util.acceptRecord();
				break;
			case 2:
				util.printRecord();
				break;
			}
		}
		CompoundInterestCalculatorUtil.releaseResource();
	}
}
