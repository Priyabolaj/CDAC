package in.Cdac.LoanAmortizationCalculator;

import java.util.Scanner;

class LoanAmortizationCalculator {
	private double principal;
	private double annualInterestRate;
	private int loanTerm;

	public LoanAmortizationCalculator(double principal, double annualInterestRate, int loanTerm) {
		this.principal = principal;
		this.annualInterestRate = annualInterestRate;
		this.loanTerm = loanTerm;
	}

	public LoanAmortizationCalculator() {
		// TODO Auto-generated constructor stub
	}

	public double getPrincipal() {
		return principal;
	}

	public void setPrincipal(double principal) {
		this.principal = principal;
	}

	public double getAnnualInterestRate() {
		return annualInterestRate;
	}

	public void setAnnualInterestRate(double annualInterestRate) {
		this.annualInterestRate = annualInterestRate;
	}

	public int getLoanTerm() {
		return loanTerm;
	}

	public void setLoanTerm(int loanTerm) {
		this.loanTerm = loanTerm;
	}

	public double calculateMonthlyPayment() {
		double monthlyInterestRate = (annualInterestRate / 100) / 12;
		int numberOfMonths = loanTerm * 12;
		return principal * (monthlyInterestRate * Math.pow(1 + monthlyInterestRate, numberOfMonths))
				/ (Math.pow(1 + monthlyInterestRate, numberOfMonths) - 1);
	}

	public double calculateTotalPayment() {
		return calculateMonthlyPayment() * loanTerm * 12;
	}

	public String toString() {
		return "LoanAmortizationCalculator [principal=" + principal + "\n annualInterestRate=" + annualInterestRate
				+ "\n loanTerm=" + loanTerm + "\n getPrincipal()=" + getPrincipal() + "\n getAnnualInterestRate()="
				+ getAnnualInterestRate() + "\n getLoanTerm()=" + getLoanTerm() + "\n calculateMonthlyPayment()="
				+ calculateMonthlyPayment() + "\n calculateTotalPayment()=" + calculateTotalPayment() + "]";
	}

}

class LoanAmortizationCalculatorUtil {
	private LoanAmortizationCalculator loan;

	public LoanAmortizationCalculatorUtil() {
		this.loan = new LoanAmortizationCalculator();
	}

	private static Scanner sc = new Scanner(System.in);

	public void acceptRecord() {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter Principal Amount (Rs.): ");
		double principal = scanner.nextDouble();
		System.out.print("Enter Annual Interest Rate (%): ");
		double annualInterestRate = scanner.nextDouble();
		System.out.print("Enter Loan Term (years): ");
		int loanTerm = scanner.nextInt();
		loan = new LoanAmortizationCalculator(principal, annualInterestRate, loanTerm);
	}

	public void printRecord() {
		System.out.println(loan.toString());
	}

	public static int menuList() {
		System.out.println("0.Exit");
		System.out.println("1.Accept Record");
		System.out.println("2.Print Record");
		System.out.print("Enter choice	:	");
		return sc.nextInt();
	}

	public static void releaseResource() {
		sc.close();
	}
}

public class Program {
	public static void main(String[] args) {
		int choice;
		LoanAmortizationCalculatorUtil util = new LoanAmortizationCalculatorUtil();
		while ((choice = LoanAmortizationCalculatorUtil.menuList()) != 0) {
			switch (choice) {
			case 1:
				util.acceptRecord();
				break;
			case 2:
				util.printRecord();
				break;
			}
		}
		LoanAmortizationCalculatorUtil.releaseResource();
	}
}