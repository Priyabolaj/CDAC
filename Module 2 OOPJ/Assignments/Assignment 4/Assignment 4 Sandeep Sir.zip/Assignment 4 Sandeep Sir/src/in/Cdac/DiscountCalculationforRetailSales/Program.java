package in.Cdac.DiscountCalculationforRetailSales;

import java.util.Scanner;
class DiscountCalculator {
	private double originalPrice;
	private double discountRate;
	public DiscountCalculator(double originalPrice, double discountRate) {
		this.originalPrice = originalPrice;
		this.discountRate = discountRate;
	}
	public double getOriginalPrice() {
		return originalPrice;
	}

	public void setOriginalPrice(double originalPrice) {
		this.originalPrice = originalPrice;
	}

	public double getDiscountRate() {
		return discountRate;
	}

	public void setDiscountRate(double discountRate) {
		this.discountRate = discountRate;
	}
	public double calculateDiscountAmount() {
		return originalPrice * (discountRate / 100);
	}
	public double calculateFinalPrice() {
		return originalPrice - calculateDiscountAmount();
	}

	public String toString() {
		return "DiscountCalculator [\noriginalPrice=" + originalPrice + "\n discountRate=" + discountRate
				+ "\n getOriginalPrice()=" + getOriginalPrice() + "\n getDiscountRate()=" + getDiscountRate()
				+ "\n calculateDiscountAmount()=" + calculateDiscountAmount() + "\n calculateFinalPrice()="
				+ calculateFinalPrice() + "\n]";
	}

}

class DiscountCalculatorUtil {
	private DiscountCalculator discountCalculator;
	private static Scanner sc = new Scanner(System.in);

	public void acceptRecord() {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter Original Price (Rs.): ");
		double originalPrice = scanner.nextDouble();
		System.out.print("Enter Discount Rate (%): ");
		double discountRate = scanner.nextDouble();
		discountCalculator = new DiscountCalculator(originalPrice, discountRate);
	}
	public void printRecord() {
		if (discountCalculator != null) {
			System.out.println(discountCalculator.toString());
		} else {
			System.out.println("No record found!");
		}
	}

	public static int menuList() {
		System.out.println("0.Exit");
		System.out.println("1.Accept Record");
		System.out.println("2.Print Record");
		System.out.print("Enter choice	:	");
		return sc.nextInt();
	}

	public static void releaseResource() {
		sc.close();
	}
}

public class Program {
	public static void main(String[] args) {
		int choice;
		DiscountCalculatorUtil util = new DiscountCalculatorUtil();
		while ((choice = DiscountCalculatorUtil.menuList()) != 0) {
			switch (choice) {
			case 1:
				util.acceptRecord();
				break;
			case 2:
				util.printRecord();
				break;
			}
		}
		DiscountCalculatorUtil.releaseResource();
	}
}
