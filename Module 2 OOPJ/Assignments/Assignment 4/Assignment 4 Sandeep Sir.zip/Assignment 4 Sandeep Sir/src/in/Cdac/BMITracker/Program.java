package in.Cdac.BMITracker;

import java.util.Scanner;

class BMITracker {
	private double weight;
	private double height;

	public BMITracker(double weight, double height) {
		this.weight = weight;
		this.height = height;
	}

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	public double getHeight() {
		return height;
	}

	public void setHeight(double height) {
		this.height = height;
	}

	public double calculateBMI() {
		return weight / (height * height);
	}

	public String classifyBMI() {
		double bmi = calculateBMI();
		if (bmi < 18.5) {
			return "Underweight";
		} else if (bmi >= 18.5 && bmi < 24.9) {
			return "Normal weight";
		} else if (bmi >= 25 && bmi < 29.9) {
			return "Overweight";
		} else {
			return "Obese";
		}
	}

	public String toString() {
		return "BMITracker [\nweight=" + weight + "\n height=" + height + "\n getWeight()=" + getWeight()
				+ "\n getHeight()=" + getHeight() + "\n calculateBMI()=" + calculateBMI() + "\n classifyBMI()="
				+ classifyBMI() + "\n]";
	}

}

class BMITrackerUtil {
	private BMITracker bmiTracker;
	private static Scanner sc = new Scanner(System.in);

	public void acceptRecord() {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter Weight (in kilograms): ");
		double weight = scanner.nextDouble();
		System.out.print("Enter Height (in meters): ");
		double height = scanner.nextDouble();
		bmiTracker = new BMITracker(weight, height);
	}

	public void printRecord() {
		System.out.println(bmiTracker.toString());
	}

	public static int menuList() {
		System.out.println("0.Exit");
		System.out.println("1.Accept Record");
		System.out.println("2.Print Record");
		System.out.print("Enter choice	:	");
		return sc.nextInt();
	}

	public static void releaseResource() {
		sc.close();
	}
}

public class Program {
	public static void main(String[] args) {
		int choice;
		BMITrackerUtil util = new BMITrackerUtil();
		while ((choice = BMITrackerUtil.menuList()) != 0) {
			switch (choice) {
			case 1:
				util.acceptRecord();
				;
				break;
			case 2:
				util.printRecord();
				;
				break;
			}
		}
		BMITrackerUtil.releaseResource();
	}
}
