package in.Cdac.TollBoothRevenueManagement;

import java.util.Scanner;

class TollBoothRevenueManager {
	private double carRate;
	private double truckRate;
	private double motorcycleRate;
	private int numCars;
	private int numTrucks;
	private int numMotorcycles;

	public TollBoothRevenueManager(double carRate, double truckRate, double motorcycleRate) {
		this.carRate = carRate;
		this.truckRate = truckRate;
		this.motorcycleRate = motorcycleRate;
	}

	public double getCarRate() {
		return carRate;
	}

	public void setCarRate(double carRate) {
		this.carRate = carRate;
	}

	public double getTruckRate() {
		return truckRate;
	}

	public void setTruckRate(double truckRate) {
		this.truckRate = truckRate;
	}

	public double getMotorcycleRate() {
		return motorcycleRate;
	}

	public void setMotorcycleRate(double motorcycleRate) {
		this.motorcycleRate = motorcycleRate;
	}

	public int getNumCars() {
		return numCars;
	}

	public void setNumCars(int numCars) {
		this.numCars = numCars;
	}

	public int getNumTrucks() {
		return numTrucks;
	}

	public void setNumTrucks(int numTrucks) {
		this.numTrucks = numTrucks;
	}

	public int getNumMotorcycles() {
		return numMotorcycles;
	}

	public void setNumMotorcycles(int numMotorcycles) {
		this.numMotorcycles = numMotorcycles;
	}

	public double calculateTotalRevenue() {
		return (numCars * carRate) + (numTrucks * truckRate) + (numMotorcycles * motorcycleRate);
	}

	public int calculateTotalVehicles() {
		return numCars + numTrucks + numMotorcycles;
	}

	public String toString() {
		return "TollBoothRevenueManager [\ncarRate=" + carRate + "\n truckRate=" + truckRate + "\n motorcycleRate="
				+ motorcycleRate + "\n numCars=" + numCars + "\n numTrucks=" + numTrucks + "\n numMotorcycles="
				+ numMotorcycles + "\n getCarRate()=" + getCarRate() + "\n getTruckRate()=" + getTruckRate()
				+ "\n getMotorcycleRate()=" + getMotorcycleRate() + "\n getNumCars()=" + getNumCars()
				+ "\n getNumTrucks()=" + getNumTrucks() + "\n getNumMotorcycles()=" + getNumMotorcycles()
				+ "\n calculateTotalRevenue()=" + calculateTotalRevenue() + "\n calculateTotalVehicles()="
				+ calculateTotalVehicles() + "\n]";
	}

}

class TollBoothRevenueManagerUtil {
	private TollBoothRevenueManager tollBooth;
	private static Scanner sc = new Scanner(System.in);

	public void acceptRecord() {
		//Scanner sc = new Scanner(System.in);
		System.out.print("Enter number of Cars: ");
		int numCars = sc.nextInt();
		System.out.print("Enter number of Trucks: ");
		int numTrucks = sc.nextInt();
		System.out.print("Enter number of Motorcycles: ");
		int numMotorcycles = sc.nextInt();

		tollBooth.setNumCars(numCars);
		tollBooth.setNumTrucks(numTrucks);
		tollBooth.setNumMotorcycles(numMotorcycles);
		//sc.close();
	}

	public void setTollRates() {
		//Scanner sc = new Scanner(System.in);
		System.out.print("Enter toll rate for Cars (Rs.): ");
		double carRate = sc.nextDouble();
		System.out.print("Enter toll rate for Trucks (Rs.): ");
		double truckRate = sc.nextDouble();
		System.out.print("Enter toll rate for Motorcycles (Rs.): ");
		double motorcycleRate = sc.nextDouble();

		tollBooth = new TollBoothRevenueManager(carRate, truckRate, motorcycleRate);
		//sc.close();
	}

	public void printRecord() {
		System.out.println(tollBooth.toString());
	}

	public static int menuList() {
		System.out.println("0.Exit");
		System.out.println("1.setTollRates");
		System.out.println("2.Accept Record");
		System.out.println("3.Print Record");
		System.out.print("Enter choice	:	");
		return sc.nextInt();
	}

	public static void releaseResource() {
		sc.close();
	}
}

public class Program {
	public static void main(String[] args) {
		int choice;
		TollBoothRevenueManagerUtil util = new TollBoothRevenueManagerUtil();
		while ((choice = TollBoothRevenueManagerUtil.menuList()) != 0) {
			switch (choice) {
			case 1:
				util.setTollRates();;
				break;
			case 2:
				util.acceptRecord();;
				break;
			case 3:
				util.printRecord();;
				break;
			}
		}
		TollBoothRevenueManagerUtil.releaseResource();
	}
}
