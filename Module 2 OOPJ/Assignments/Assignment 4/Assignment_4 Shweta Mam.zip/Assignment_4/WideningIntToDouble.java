package in.Cdac.Assignment_4;

public class WideningIntToDouble {
	public static void main(String[] args) {
        int num = 10;
        double widenedNum = num;  
        System.out.println("Widened int to double: " + widenedNum);
    }
}
