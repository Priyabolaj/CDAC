package in.Cdac.Assignment_4;

public class WideningConversions {
	public static void main(String[] args) {

		int num = 25;
		double toDouble = num;
		float toFloat = num;
		String toString = Integer.toString(num);

		boolean toBoolean = (num != 0);

		System.out.println("int to double: " + toDouble);
		System.out.println("int to float: " + toFloat);
		System.out.println("int to string: " + toString);
		System.out.println("int to boolean: " + toBoolean);
	}
}
