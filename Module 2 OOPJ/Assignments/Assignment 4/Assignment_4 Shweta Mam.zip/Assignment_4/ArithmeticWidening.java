package in.Cdac.Assignment_4;

public class ArithmeticWidening {
	public static void main(String[] args) {
		int num1 = 5;
		double num2 = 6.5;
		float num3 = 3.2f;

		double result1 = num1 + num2;
		float result2 = num1 + num3; 

		System.out.println("Result of int + double: " + result1);
		System.out.println("Result of int + float: " + result2);
	}

}
