package in.Cdac.Assignment_4;

public class NarrowingDoubleToInt {
	public static void main(String[] args) {
        double num = 10.99;
        int narrowedNum = (int) num;  
        System.out.println("Narrowed double to int: " + narrowedNum);
    }
}
