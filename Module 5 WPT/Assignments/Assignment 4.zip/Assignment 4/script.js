// Function for Exercise 1
function toUpperCase(str) {
    return str.toUpperCase();
}

function processData(input, callback) {
    const result = callback(input);
    document.getElementById("output1").textContent = result;
}

function runExercise1() {
    processData("hello world", toUpperCase);
}

// Function for Exercise 2
function forEachElement(array, callback) {
    let output = "";
    for (let i = 0; i < array.length; i++) {
        output += `Index ${i}: ${callback(array[i], i)}\n`;
    }
    document.getElementById("output2").textContent = output;
}

function runExercise2() {
    forEachElement([1, 2, 3, 4], (element, index) => element * 2);
}

// Function for Exercise 3 & 4 with Error Handling
function fetchData(url, callback) {
    const outputElement = document.getElementById("output3");
    outputElement.textContent = `Fetching data from ${url}...\n`;

    setTimeout(() => {
        const errorOccurred = Math.random() > 0.5; // Simulate a 50% chance of error
        if (errorOccurred) {
            callback("Network error occurred!", null);
        } else {
            const response = "Sample data from " + url;
            callback(null, response);
        }
    }, 2000);
}

function runExercise3() {
    fetchData("https://example.com", (error, response) => {
        const outputElement = document.getElementById("output3");
        if (error) {
            outputElement.textContent += `Error: ${error}\n`;
        } else {
            outputElement.textContent += `Response received: ${response}\n`;
        }
    });
}

// Function for Exercise 5 with Chained Callbacks
function processDataWithChaining(data, callback) {
    const outputElement = document.getElementById("output5");
    outputElement.textContent += "Processing data...\n";

    setTimeout(() => {
        const processedData = data.toUpperCase();
        callback(processedData);
    }, 1000);
}

function runExercise5() {
    fetchData("https://example.com", (error, response) => {
        const outputElement = document.getElementById("output5");

        if (error) {
            outputElement.textContent = `Error: ${error}\n`;
        } else {
            processDataWithChaining(response, (processedData) => {
                outputElement.textContent += `Processed Data: ${processedData}\n`;
            });
        }
    });
}
