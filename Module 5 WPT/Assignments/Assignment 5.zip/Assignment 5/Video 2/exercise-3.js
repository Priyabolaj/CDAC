/*1. Create a function called "goGetCandies" which will return a Promise Object that resolves to the value: { candy: "sour keys", quantity: 10]
    This should take 2 seconds
2. Create another Function called "sellCandies" that will take a candy Object like above and return A a Number that is 25 quantity. This will be how much (in cents) we get for our candies. However, make this function take 3 seconds to do this math (return a Promise with a setTimeout with the answer).
3. Write an async function that uses await to:
    1. Get the candy object from goGetCandies()
    2. Passes it to "sellCandies" and waits for the response
    3. Prints out how much money we made from our sale
4. Do the same steps as #3 but with vanilla Promises.

Q1: Which of these 2 methods do you prefer?
Q2: Which of these 2 methods is easier to read?*/

const goGetCandies = () =>{

};

const sellCandies = (candy) =>{

};

const useCandies =async() => {
};
console.log("Program starting");
const timel = new Date();
    
    //useCandies();

const candy = goGetCandies();
candy.then ((result) => {
    const sellValue = sellCandies(result);
    console.log(sellValue);
    sellValue.then((value)=> {
        console.log(value);
        const time2 = new Date();
        console.log(`${time2 - time1}ms passed`);
    });
});
console.log("Program complete");